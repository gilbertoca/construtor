package com.gilbertoca.gfi.model.ger;

import java.io.Serializable;
import java.util.Set;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="ger_escolaridade")
public class Escolaridade implements Serializable {
	@Id
	private short cdescolaridade;

	private String dcescolaridade;

	@OneToMany(mappedBy="cdescolaridade")
	private Set<PessoaCaracteristica> gerPessoacaracteristicaCollection;

	private static final long serialVersionUID = 1L;

	public Escolaridade() {
		super();
	}

	public short getCdescolaridade() {
		return this.cdescolaridade;
	}

	public void setCdescolaridade(short cdescolaridade) {
		this.cdescolaridade = cdescolaridade;
	}

	public String getDcescolaridade() {
		return this.dcescolaridade;
	}

	public void setDcescolaridade(String dcescolaridade) {
		this.dcescolaridade = dcescolaridade;
	}

	public Set<PessoaCaracteristica> getGerPessoacaracteristicaCollection() {
		return this.gerPessoacaracteristicaCollection;
	}

	public void setGerPessoacaracteristicaCollection(Set<PessoaCaracteristica> gerPessoacaracteristicaCollection) {
		this.gerPessoacaracteristicaCollection = gerPessoacaracteristicaCollection;
	}

}
