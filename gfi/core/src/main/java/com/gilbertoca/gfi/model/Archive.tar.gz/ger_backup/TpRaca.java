package com.gilbertoca.gfi.model.ger;

import java.io.Serializable;
import java.util.Set;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="ger_tpraca")
public class TpRaca implements Serializable {
	@Id
	private short cdtpraca;

	private String dctpraca;

	@OneToMany(mappedBy="cdtpraca")
	private Set<PessoaCaracteristica> gerPessoacaracteristicaCollection;

	private static final long serialVersionUID = 1L;

	public TpRaca() {
		super();
	}

	public short getCdtpraca() {
		return this.cdtpraca;
	}

	public void setCdtpraca(short cdtpraca) {
		this.cdtpraca = cdtpraca;
	}

	public String getDctpraca() {
		return this.dctpraca;
	}

	public void setDctpraca(String dctpraca) {
		this.dctpraca = dctpraca;
	}

	public Set<PessoaCaracteristica> getGerPessoacaracteristicaCollection() {
		return this.gerPessoacaracteristicaCollection;
	}

	public void setGerPessoacaracteristicaCollection(Set<PessoaCaracteristica> gerPessoacaracteristicaCollection) {
		this.gerPessoacaracteristicaCollection = gerPessoacaracteristicaCollection;
	}

}
