package com.gilbertoca.gfi.model.ger;

import java.io.Serializable;
import java.util.Set;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="ger_tpmotivoiniciodependencia")
public class TpMotivoInicioDependencia implements Serializable {
	@Id
	private short cdtpmotivoiniciodependencia;

	private String dcmotivoiniciodependencia;

	@OneToMany(mappedBy="cdtpmotivoiniciodependencia")
	private Set<PessoaDependencia> gerPessoadependenciaCollection;

	private static final long serialVersionUID = 1L;

	public TpMotivoInicioDependencia() {
		super();
	}

	public short getCdtpmotivoiniciodependencia() {
		return this.cdtpmotivoiniciodependencia;
	}

	public void setCdtpmotivoiniciodependencia(short cdtpmotivoiniciodependencia) {
		this.cdtpmotivoiniciodependencia = cdtpmotivoiniciodependencia;
	}

	public String getDcmotivoiniciodependencia() {
		return this.dcmotivoiniciodependencia;
	}

	public void setDcmotivoiniciodependencia(String dcmotivoiniciodependencia) {
		this.dcmotivoiniciodependencia = dcmotivoiniciodependencia;
	}

	public Set<PessoaDependencia> getGerPessoadependenciaCollection() {
		return this.gerPessoadependenciaCollection;
	}

	public void setGerPessoadependenciaCollection(Set<PessoaDependencia> gerPessoadependenciaCollection) {
		this.gerPessoadependenciaCollection = gerPessoadependenciaCollection;
	}

}
