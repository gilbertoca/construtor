package com.gilbertoca.gfi.model.ger;

import java.io.Serializable;
import java.util.Set;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="ger_tpdeficiencia")
public class TpDeficiencia implements Serializable {
	@Id
	private short cdtpdeficiencia;

	private String dctpdeficiencia;

	@OneToMany(mappedBy="cdtpdeficiencia")
	private Set<PessoaCaracteristica> gerPessoacaracteristicaCollection;

	private static final long serialVersionUID = 1L;

	public TpDeficiencia() {
		super();
	}

	public short getCdtpdeficiencia() {
		return this.cdtpdeficiencia;
	}

	public void setCdtpdeficiencia(short cdtpdeficiencia) {
		this.cdtpdeficiencia = cdtpdeficiencia;
	}

	public String getDctpdeficiencia() {
		return this.dctpdeficiencia;
	}

	public void setDctpdeficiencia(String dctpdeficiencia) {
		this.dctpdeficiencia = dctpdeficiencia;
	}

	public Set<PessoaCaracteristica> getGerPessoacaracteristicaCollection() {
		return this.gerPessoacaracteristicaCollection;
	}

	public void setGerPessoacaracteristicaCollection(Set<PessoaCaracteristica> gerPessoacaracteristicaCollection) {
		this.gerPessoacaracteristicaCollection = gerPessoacaracteristicaCollection;
	}

}
