package com.gilbertoca.gfi.model.ger;

import java.io.Serializable;
import java.util.Set;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="ger_tpreligiao")
public class TpReligiao implements Serializable {
	@Id
	private short cdtpreligiao;

	private String dctpreligiao;

	@OneToMany(mappedBy="cdtpreligiao")
	private Set<PessoaCaracteristica> gerPessoacaracteristicaCollection;

	private static final long serialVersionUID = 1L;

	public TpReligiao() {
		super();
	}

	public short getCdtpreligiao() {
		return this.cdtpreligiao;
	}

	public void setCdtpreligiao(short cdtpreligiao) {
		this.cdtpreligiao = cdtpreligiao;
	}

	public String getDctpreligiao() {
		return this.dctpreligiao;
	}

	public void setDctpreligiao(String dctpreligiao) {
		this.dctpreligiao = dctpreligiao;
	}

	public Set<PessoaCaracteristica> getGerPessoacaracteristicaCollection() {
		return this.gerPessoacaracteristicaCollection;
	}

	public void setGerPessoacaracteristicaCollection(Set<PessoaCaracteristica> gerPessoacaracteristicaCollection) {
		this.gerPessoacaracteristicaCollection = gerPessoacaracteristicaCollection;
	}

}
