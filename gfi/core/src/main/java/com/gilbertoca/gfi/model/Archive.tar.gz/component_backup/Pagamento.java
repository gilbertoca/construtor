package com.gilbertoca.gfi.model.component;

import java.io.Serializable;
import java.util.Date;


import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;

/**
 * @author Gilberto
 * Representa o pagamento de um documento: Duplicata, Nota Promiss�ria, etc.
 */
public class Pagamento implements Serializable {
	protected Date dtVencimento;
	protected Double valorDocumento = new Double(0.0);
    protected Double desconto;
    protected Double deducoes;
    protected Double juros;
    protected Double acrescimos;
	protected Date dtPagamento;	
    protected Double valorCobrado;
	
    /**
     * @spring.validator type="required"
     */
    public void setValorDocumento(Double valorDocumento) {
        this.valorDocumento = valorDocumento;
    }

    /**
     * @hibernate.property not-null = "false"
     * @hibernate.column name="valor_documento"  length="8"
     * Valor do documento.
     */
    public Double getValorDocumento() {
        return valorDocumento;
    }

    /**
     * @hibernate.property not-null = "false"
     * @hibernate.column name="dt_vencimento"  length="8"
     * Data do vencimento.
     */
    public Date getDtVencimento() {
        return dtVencimento;
    }

    /**
     * @spring.validator type="required, date"
     * @spring.validator-var name="mask" value="dd/MM/yyyy"
     */
    public void setDtVencimento(Date dtVencimento) {
        this.dtVencimento = dtVencimento;
    }

    /**
     * @hibernate.property not-null = "false"
     * @hibernate.column name="dt_pagamento"  length="8"
     * Data do pagamento.
     */
    public Date getDtPagamento() {
        return dtPagamento;
    }

    /**
     * @param dtPagamento
     *            The dtPagamento to set.
     */
    public void setDtPagamento(Date dtPagamento) {
        this.dtPagamento = dtPagamento;
    }
    
    /** 
     * @hibernate.property not-null = "false"
     *  @hibernate.column name="desconto" length="8"
     *  Desconto/Abatimento.
     */
    public Double getDesconto() {
        return this.desconto;
    }

    public void setDesconto(Double desconto) {
        this.desconto = desconto;
    }

    /** 
     * @hibernate.property not-null = "false"
     *  @hibernate.column name="deducoes" length="8"
     *  Dedu��es.
     */
    public Double getDeducoes() {
        return this.deducoes;
    }

    public void setDeducoes(Double deducoes) {
        this.deducoes = deducoes;
    }

    /** 
     * @hibernate.property not-null = "false"
     *  @hibernate.column name="juros" length="8"
     *  Juros Mora/Multa.
     */
    public Double getJuros() {
        return this.juros;
    }

    public void setJuros(Double juros) {
        this.juros = juros;
    }

    /** 
     * @hibernate.property not-null = "false"
     * hibernate.column name="acrescimos" length="8"
     * Acr�scimos.
     */
    public Double getAcrescimos() {
        return this.acrescimos;
    }

    public void setAcrescimos(Double acrescimos) {
        this.acrescimos = acrescimos;
    }

    /** 
     * @hibernate.property not-null = "false"
     *  @hibernate.column name="valor_cobrado" length="8"
     *  Valor cobrado.
     */
    public Double getValorCobrado() {
        return this.valorCobrado;
    }
	
    public void setValorCobrado(Double total) {
        this.valorCobrado = total;
    }
	
    /**
     * @see java.lang.Object#hashCode()
     */
    public int hashCode() {
        return new HashCodeBuilder(-897267317, -1108636155).append(this.dtPagamento)
        												   .append(this.acrescimos)
        												   .append(this.desconto)
        												   .append(this.valorCobrado)
        												   .append(this.dtVencimento)
        												   .append(this.deducoes)
        												   .append(this.juros)
        												   .append(this.valorDocumento)
        												   .toHashCode();
    }
    /**
     * @see java.lang.Object#toString()
     */
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE)
                .append("juros", this.juros)
                .append("valorDocumento", this.valorDocumento)
                .append("desconto", this.desconto)
                .append("dtPagamento", this.dtPagamento)
                .append("valorCobrado", this.valorCobrado)
                .append("acrescimos", this.acrescimos)
                .append("deducoes", this.deducoes)
                .append("dtVencimento", this.dtVencimento)
                .toString();
    }
    /**
     * @see java.lang.Object#equals(Object)
     */
    public boolean equals(Object object) {
        if (!(object instanceof Pagamento)) {
            return false;
        }
        Pagamento rhs = (Pagamento) object;
        return new EqualsBuilder().append(this.dtPagamento, rhs.dtPagamento)
                				  .append(this.acrescimos, rhs.acrescimos)
                				  .append(this.desconto, rhs.desconto)
                				  .append(this.valorCobrado, rhs.valorCobrado)
                				  .append(this.dtVencimento, rhs.dtVencimento)
                				  .append(this.deducoes, rhs.deducoes)
                				  .append(this.juros, rhs.juros)
                				  .append(this.valorDocumento, rhs.valorDocumento)
                				  .isEquals();
    }
}
