package com.gilbertoca.gfi.model.ger;

import java.io.Serializable;
import java.util.Set;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="ger_tpmotivofimdependencia")
public class TpMotivoFimDependencia implements Serializable {
	@Id
	private short cdtpmotivofimdependencia;

	private String dctpmotivofimdependencia;

	@OneToMany(mappedBy="cdtpmotivofimdependencia")
	private Set<PessoaDependencia> gerPessoadependenciaCollection;

	private static final long serialVersionUID = 1L;

	public TpMotivoFimDependencia() {
		super();
	}

	public short getCdtpmotivofimdependencia() {
		return this.cdtpmotivofimdependencia;
	}

	public void setCdtpmotivofimdependencia(short cdtpmotivofimdependencia) {
		this.cdtpmotivofimdependencia = cdtpmotivofimdependencia;
	}

	public String getDctpmotivofimdependencia() {
		return this.dctpmotivofimdependencia;
	}

	public void setDctpmotivofimdependencia(String dctpmotivofimdependencia) {
		this.dctpmotivofimdependencia = dctpmotivofimdependencia;
	}

	public Set<PessoaDependencia> getGerPessoadependenciaCollection() {
		return this.gerPessoadependenciaCollection;
	}

	public void setGerPessoadependenciaCollection(Set<PessoaDependencia> gerPessoadependenciaCollection) {
		this.gerPessoadependenciaCollection = gerPessoadependenciaCollection;
	}

}
