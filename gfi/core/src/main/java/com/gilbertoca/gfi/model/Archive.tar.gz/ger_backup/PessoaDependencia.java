package com.gilbertoca.gfi.model.ger;

import java.io.Serializable;
import java.sql.Date;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="ger_pessoadependencia")
public class PessoaDependencia implements Serializable {
	@Id
	private int cdpessoadependencia;

	private Date dtiniciodependencia;

	private Date dtfimdependencia;

	private int cdpessoadependente;

	private short fldepfinsprevidenciarios;

	private short flpensionista;

	private Date dtprevistafimdependencia;

	@ManyToOne
	@JoinColumn(name="cdtpdependencia")
	private TpDependencia cdtpdependencia;

	@ManyToOne
	@JoinColumn(name="cdtpgrauparentesco")
	private TpGrauParentesco cdtpgrauparentesco;

	@ManyToOne
	@JoinColumn(name="cdtpmotivofimdependencia")
	private TpMotivoFimDependencia cdtpmotivofimdependencia;

	@ManyToOne
	@JoinColumn(name="cdpessoa")
	private Pessoa cdpessoa;

	@ManyToOne
	@JoinColumn(name="cdtpmotivoiniciodependencia")
	private TpMotivoInicioDependencia cdtpmotivoiniciodependencia;

	private static final long serialVersionUID = 1L;

	public PessoaDependencia() {
		super();
	}

	public int getCdpessoadependencia() {
		return this.cdpessoadependencia;
	}

	public void setCdpessoadependencia(int cdpessoadependencia) {
		this.cdpessoadependencia = cdpessoadependencia;
	}

	public Date getDtiniciodependencia() {
		return this.dtiniciodependencia;
	}

	public void setDtiniciodependencia(Date dtiniciodependencia) {
		this.dtiniciodependencia = dtiniciodependencia;
	}

	public Date getDtfimdependencia() {
		return this.dtfimdependencia;
	}

	public void setDtfimdependencia(Date dtfimdependencia) {
		this.dtfimdependencia = dtfimdependencia;
	}

	public int getCdpessoadependente() {
		return this.cdpessoadependente;
	}

	public void setCdpessoadependente(int cdpessoadependente) {
		this.cdpessoadependente = cdpessoadependente;
	}

	public short getFldepfinsprevidenciarios() {
		return this.fldepfinsprevidenciarios;
	}

	public void setFldepfinsprevidenciarios(short fldepfinsprevidenciarios) {
		this.fldepfinsprevidenciarios = fldepfinsprevidenciarios;
	}

	public short getFlpensionista() {
		return this.flpensionista;
	}

	public void setFlpensionista(short flpensionista) {
		this.flpensionista = flpensionista;
	}

	public Date getDtprevistafimdependencia() {
		return this.dtprevistafimdependencia;
	}

	public void setDtprevistafimdependencia(Date dtprevistafimdependencia) {
		this.dtprevistafimdependencia = dtprevistafimdependencia;
	}

	public TpDependencia getCdtpdependencia() {
		return this.cdtpdependencia;
	}

	public void setCdtpdependencia(TpDependencia cdtpdependencia) {
		this.cdtpdependencia = cdtpdependencia;
	}

	public TpGrauParentesco getCdtpgrauparentesco() {
		return this.cdtpgrauparentesco;
	}

	public void setCdtpgrauparentesco(TpGrauParentesco cdtpgrauparentesco) {
		this.cdtpgrauparentesco = cdtpgrauparentesco;
	}

	public TpMotivoFimDependencia getCdtpmotivofimdependencia() {
		return this.cdtpmotivofimdependencia;
	}

	public void setCdtpmotivofimdependencia(TpMotivoFimDependencia cdtpmotivofimdependencia) {
		this.cdtpmotivofimdependencia = cdtpmotivofimdependencia;
	}

	public Pessoa getCdpessoa() {
		return this.cdpessoa;
	}

	public void setCdpessoa(Pessoa cdpessoa) {
		this.cdpessoa = cdpessoa;
	}

	public TpMotivoInicioDependencia getCdtpmotivoiniciodependencia() {
		return this.cdtpmotivoiniciodependencia;
	}

	public void setCdtpmotivoiniciodependencia(TpMotivoInicioDependencia cdtpmotivoiniciodependencia) {
		this.cdtpmotivoiniciodependencia = cdtpmotivoiniciodependencia;
	}

}
