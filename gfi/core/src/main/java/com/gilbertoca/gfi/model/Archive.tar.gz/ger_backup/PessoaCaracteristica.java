package com.gilbertoca.gfi.model.ger;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="ger_pessoacaracteristica")
public class PessoaCaracteristica implements Serializable {
	@Id
	@Column(name="cdpessoa", insertable=false, updatable=false)
	private int cdpessoa2;

	private int cdnaturalidade;

	private short fldoadorsangue;

	@ManyToOne
	@JoinColumn(name="cdpessoa")
	private Pessoa cdpessoa;

	@ManyToOne
	@JoinColumn(name="cdtpdeficiencia")
	private TpDeficiencia cdtpdeficiencia;

	@ManyToOne
	@JoinColumn(name="cdtpsanguineo")
	private TpSanguineo cdtpsanguineo;

	@ManyToOne
	@JoinColumn(name="cdtpnacionalidade")
	private TpNacionalidade cdtpnacionalidade;

	@ManyToOne
	@JoinColumn(name="cdtpreligiao")
	private TpReligiao cdtpreligiao;

	@ManyToOne
	@JoinColumn(name="cdescolaridade")
	private Escolaridade cdescolaridade;

	@ManyToOne
	@JoinColumn(name="cdestadocivil")
	private EstadoCivil cdestadocivil;

	@ManyToOne
	@JoinColumn(name="cdtpraca")
	private TpRaca cdtpraca;

	private static final long serialVersionUID = 1L;

	public PessoaCaracteristica() {
		super();
	}

	public int getCdpessoa2() {
		return this.cdpessoa2;
	}

	public void setCdpessoa2(int cdpessoa2) {
		this.cdpessoa2 = cdpessoa2;
	}

	public int getCdnaturalidade() {
		return this.cdnaturalidade;
	}

	public void setCdnaturalidade(int cdnaturalidade) {
		this.cdnaturalidade = cdnaturalidade;
	}

	public short getFldoadorsangue() {
		return this.fldoadorsangue;
	}

	public void setFldoadorsangue(short fldoadorsangue) {
		this.fldoadorsangue = fldoadorsangue;
	}

	public Pessoa getCdpessoa() {
		return this.cdpessoa;
	}

	public void setCdpessoa(Pessoa cdpessoa) {
		this.cdpessoa = cdpessoa;
	}

	public TpDeficiencia getCdtpdeficiencia() {
		return this.cdtpdeficiencia;
	}

	public void setCdtpdeficiencia(TpDeficiencia cdtpdeficiencia) {
		this.cdtpdeficiencia = cdtpdeficiencia;
	}

	public TpSanguineo getCdtpsanguineo() {
		return this.cdtpsanguineo;
	}

	public void setCdtpsanguineo(TpSanguineo cdtpsanguineo) {
		this.cdtpsanguineo = cdtpsanguineo;
	}

	public TpNacionalidade getCdtpnacionalidade() {
		return this.cdtpnacionalidade;
	}

	public void setCdtpnacionalidade(TpNacionalidade cdtpnacionalidade) {
		this.cdtpnacionalidade = cdtpnacionalidade;
	}

	public TpReligiao getCdtpreligiao() {
		return this.cdtpreligiao;
	}

	public void setCdtpreligiao(TpReligiao cdtpreligiao) {
		this.cdtpreligiao = cdtpreligiao;
	}

	public Escolaridade getCdescolaridade() {
		return this.cdescolaridade;
	}

	public void setCdescolaridade(Escolaridade cdescolaridade) {
		this.cdescolaridade = cdescolaridade;
	}

	public EstadoCivil getCdestadocivil() {
		return this.cdestadocivil;
	}

	public void setCdestadocivil(EstadoCivil cdestadocivil) {
		this.cdestadocivil = cdestadocivil;
	}

	public TpRaca getCdtpraca() {
		return this.cdtpraca;
	}

	public void setCdtpraca(TpRaca cdtpraca) {
		this.cdtpraca = cdtpraca;
	}

}
