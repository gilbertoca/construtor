package com.gilbertoca.gfi.model.ger;

import java.io.Serializable;
import java.util.Set;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="ger_estadocivil")
public class EstadoCivil implements Serializable {
	@Id
	private short cdestadocivil;

	private String dcestadocivil;

	@OneToMany(mappedBy="cdestadocivil")
	private Set<PessoaCaracteristica> gerPessoacaracteristicaCollection;

	private static final long serialVersionUID = 1L;

	public EstadoCivil() {
		super();
	}

	public short getCdestadocivil() {
		return this.cdestadocivil;
	}

	public void setCdestadocivil(short cdestadocivil) {
		this.cdestadocivil = cdestadocivil;
	}

	public String getDcestadocivil() {
		return this.dcestadocivil;
	}

	public void setDcestadocivil(String dcestadocivil) {
		this.dcestadocivil = dcestadocivil;
	}

	public Set<PessoaCaracteristica> getGerPessoacaracteristicaCollection() {
		return this.gerPessoacaracteristicaCollection;
	}

	public void setGerPessoacaracteristicaCollection(Set<PessoaCaracteristica> gerPessoacaracteristicaCollection) {
		this.gerPessoacaracteristicaCollection = gerPessoacaracteristicaCollection;
	}

}
