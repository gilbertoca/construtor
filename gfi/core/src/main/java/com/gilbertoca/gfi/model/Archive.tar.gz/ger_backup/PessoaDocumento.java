package com.gilbertoca.gfi.model.ger;

import java.io.Serializable;
import java.sql.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="ger_pessoadocumento")
public class PessoaDocumento implements Serializable {
	@Id
	@Column(name="cdpessoa", insertable=false, updatable=false)
	private int cdpessoa2;

	private Date ctpsemissao;

	private String ctpsnumero;

	private String numerosus;

	private Date cnhvalidade;

	private String crvsm;

	private String titelsecao;

	private String titelzona;

	private Date cnhemissao;

	private String pispasep;

	private String crnumero;

	private Date titelemissao;

	private Date almemissao;

	private String cnhcategoria;

	private String crcategoria;

	private String cnhnumero;

	private String almserie;

	private String almregmilitar;

	private String crvrm;

	private String ctpsserie;

	private String crserie;

	private String almvrm;

	private String almcsm;

	private String titelnumero;

	private Date cremissao;

	private String ctpsuf;

	@ManyToOne
	@JoinColumn(name="cdpessoa")
	private Pessoa cdpessoa;

	private static final long serialVersionUID = 1L;

	public PessoaDocumento() {
		super();
	}

	public int getCdpessoa2() {
		return this.cdpessoa2;
	}

	public void setCdpessoa2(int cdpessoa2) {
		this.cdpessoa2 = cdpessoa2;
	}

	public Date getCtpsemissao() {
		return this.ctpsemissao;
	}

	public void setCtpsemissao(Date ctpsemissao) {
		this.ctpsemissao = ctpsemissao;
	}

	public String getCtpsnumero() {
		return this.ctpsnumero;
	}

	public void setCtpsnumero(String ctpsnumero) {
		this.ctpsnumero = ctpsnumero;
	}

	public String getNumerosus() {
		return this.numerosus;
	}

	public void setNumerosus(String numerosus) {
		this.numerosus = numerosus;
	}

	public Date getCnhvalidade() {
		return this.cnhvalidade;
	}

	public void setCnhvalidade(Date cnhvalidade) {
		this.cnhvalidade = cnhvalidade;
	}

	public String getCrvsm() {
		return this.crvsm;
	}

	public void setCrvsm(String crvsm) {
		this.crvsm = crvsm;
	}

	public String getTitelsecao() {
		return this.titelsecao;
	}

	public void setTitelsecao(String titelsecao) {
		this.titelsecao = titelsecao;
	}

	public String getTitelzona() {
		return this.titelzona;
	}

	public void setTitelzona(String titelzona) {
		this.titelzona = titelzona;
	}

	public Date getCnhemissao() {
		return this.cnhemissao;
	}

	public void setCnhemissao(Date cnhemissao) {
		this.cnhemissao = cnhemissao;
	}

	public String getPispasep() {
		return this.pispasep;
	}

	public void setPispasep(String pispasep) {
		this.pispasep = pispasep;
	}

	public String getCrnumero() {
		return this.crnumero;
	}

	public void setCrnumero(String crnumero) {
		this.crnumero = crnumero;
	}

	public Date getTitelemissao() {
		return this.titelemissao;
	}

	public void setTitelemissao(Date titelemissao) {
		this.titelemissao = titelemissao;
	}

	public Date getAlmemissao() {
		return this.almemissao;
	}

	public void setAlmemissao(Date almemissao) {
		this.almemissao = almemissao;
	}

	public String getCnhcategoria() {
		return this.cnhcategoria;
	}

	public void setCnhcategoria(String cnhcategoria) {
		this.cnhcategoria = cnhcategoria;
	}

	public String getCrcategoria() {
		return this.crcategoria;
	}

	public void setCrcategoria(String crcategoria) {
		this.crcategoria = crcategoria;
	}

	public String getCnhnumero() {
		return this.cnhnumero;
	}

	public void setCnhnumero(String cnhnumero) {
		this.cnhnumero = cnhnumero;
	}

	public String getAlmserie() {
		return this.almserie;
	}

	public void setAlmserie(String almserie) {
		this.almserie = almserie;
	}

	public String getAlmregmilitar() {
		return this.almregmilitar;
	}

	public void setAlmregmilitar(String almregmilitar) {
		this.almregmilitar = almregmilitar;
	}

	public String getCrvrm() {
		return this.crvrm;
	}

	public void setCrvrm(String crvrm) {
		this.crvrm = crvrm;
	}

	public String getCtpsserie() {
		return this.ctpsserie;
	}

	public void setCtpsserie(String ctpsserie) {
		this.ctpsserie = ctpsserie;
	}

	public String getCrserie() {
		return this.crserie;
	}

	public void setCrserie(String crserie) {
		this.crserie = crserie;
	}

	public String getAlmvrm() {
		return this.almvrm;
	}

	public void setAlmvrm(String almvrm) {
		this.almvrm = almvrm;
	}

	public String getAlmcsm() {
		return this.almcsm;
	}

	public void setAlmcsm(String almcsm) {
		this.almcsm = almcsm;
	}

	public String getTitelnumero() {
		return this.titelnumero;
	}

	public void setTitelnumero(String titelnumero) {
		this.titelnumero = titelnumero;
	}

	public Date getCremissao() {
		return this.cremissao;
	}

	public void setCremissao(Date cremissao) {
		this.cremissao = cremissao;
	}

	public String getCtpsuf() {
		return this.ctpsuf;
	}

	public void setCtpsuf(String ctpsuf) {
		this.ctpsuf = ctpsuf;
	}

	public Pessoa getCdpessoa() {
		return this.cdpessoa;
	}

	public void setCdpessoa(Pessoa cdpessoa) {
		this.cdpessoa = cdpessoa;
	}

}
