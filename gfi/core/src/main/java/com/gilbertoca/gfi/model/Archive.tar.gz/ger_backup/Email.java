package com.gilbertoca.gfi.model.ger;

import java.io.Serializable;
import javax.persistence.Embeddable;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="ger_email")
public class Email implements Serializable {
	@EmbeddedId
	private Email.PK pk;

	@ManyToOne
	@JoinColumn(name="cdpessoa")
	private Pessoa cdpessoa;

	private static final long serialVersionUID = 1L;

	public Email() {
		super();
	}

	public Email.PK getPk() {
		return this.pk;
	}

	public void setPk(Email.PK pk) {
		this.pk = pk;
	}

	public Pessoa getCdpessoa() {
		return this.cdpessoa;
	}

	public void setCdpessoa(Pessoa cdpessoa) {
		this.cdpessoa = cdpessoa;
	}


	@Embeddable
	public static class PK implements Serializable {
		private int cdpessoa2;
		private String email;
		private static final long serialVersionUID = 1L;

		public PK() {
			super();
		}

		public int getCdpessoa2() {
			return this.cdpessoa2;
		}

		public void setCdpessoa2(int cdpessoa2) {
			this.cdpessoa2 = cdpessoa2;
		}

		public String getEmail() {
			return this.email;
		}

		public void setEmail(String email) {
			this.email = email;
		}

		@Override
		public boolean equals(Object o) {
			if (o == this) {
				return true;
			}
			if ( ! (o instanceof PK)) {
				return false;
			}
			PK other = (PK) o;
			return (this.cdpessoa2 == other.cdpessoa2)
				&& this.email.equals(other.email);
		}

		@Override
		public int hashCode() {
			return this.cdpessoa2
				^ this.email.hashCode();
		}

	}

}
