package com.gilbertoca.gfi.model.ger;

import java.io.Serializable;
import java.util.Set;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="ger_tpgrauparentesco")
public class TpGrauParentesco implements Serializable {
	@Id
	private short cdtpgrauparentesco;

	private String dctpgrauparentesco;

	@OneToMany(mappedBy="cdtpgrauparentesco")
	private Set<PessoaDependencia> gerPessoadependenciaCollection;

	private static final long serialVersionUID = 1L;

	public TpGrauParentesco() {
		super();
	}

	public short getCdtpgrauparentesco() {
		return this.cdtpgrauparentesco;
	}

	public void setCdtpgrauparentesco(short cdtpgrauparentesco) {
		this.cdtpgrauparentesco = cdtpgrauparentesco;
	}

	public String getDctpgrauparentesco() {
		return this.dctpgrauparentesco;
	}

	public void setDctpgrauparentesco(String dctpgrauparentesco) {
		this.dctpgrauparentesco = dctpgrauparentesco;
	}

	public Set<PessoaDependencia> getGerPessoadependenciaCollection() {
		return this.gerPessoadependenciaCollection;
	}

	public void setGerPessoadependenciaCollection(Set<PessoaDependencia> gerPessoadependenciaCollection) {
		this.gerPessoadependenciaCollection = gerPessoadependenciaCollection;
	}

}
