package com.gilbertoca.gfi.model.ger;

import java.io.Serializable;
import java.util.Set;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="ger_tpdependencia")
public class TpDependencia implements Serializable {
	@Id
	private short cdtpdependencia;

	private String dctpdependencia;

	@OneToMany(mappedBy="cdtpdependencia")
	private Set<PessoaDependencia> gerPessoadependenciaCollection;

	private static final long serialVersionUID = 1L;

	public TpDependencia() {
		super();
	}

	public short getCdtpdependencia() {
		return this.cdtpdependencia;
	}

	public void setCdtpdependencia(short cdtpdependencia) {
		this.cdtpdependencia = cdtpdependencia;
	}

	public String getDctpdependencia() {
		return this.dctpdependencia;
	}

	public void setDctpdependencia(String dctpdependencia) {
		this.dctpdependencia = dctpdependencia;
	}

	public Set<PessoaDependencia> getGerPessoadependenciaCollection() {
		return this.gerPessoadependenciaCollection;
	}

	public void setGerPessoadependenciaCollection(Set<PessoaDependencia> gerPessoadependenciaCollection) {
		this.gerPessoadependenciaCollection = gerPessoadependenciaCollection;
	}

}
