package com.gilbertoca.gfi.model.ger;

import java.io.Serializable;
import java.util.Set;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="ger_tpnacionalidade")
public class TpNacionalidade implements Serializable {
	@Id
	private short cdtpnacionalidade;

	private String dctpnacionalidade;

	@OneToMany(mappedBy="cdtpnacionalidade")
	private Set<PessoaCaracteristica> gerPessoacaracteristicaCollection;

	private static final long serialVersionUID = 1L;

	public TpNacionalidade() {
		super();
	}

	public short getCdtpnacionalidade() {
		return this.cdtpnacionalidade;
	}

	public void setCdtpnacionalidade(short cdtpnacionalidade) {
		this.cdtpnacionalidade = cdtpnacionalidade;
	}

	public String getDctpnacionalidade() {
		return this.dctpnacionalidade;
	}

	public void setDctpnacionalidade(String dctpnacionalidade) {
		this.dctpnacionalidade = dctpnacionalidade;
	}

	public Set<PessoaCaracteristica> getGerPessoacaracteristicaCollection() {
		return this.gerPessoacaracteristicaCollection;
	}

	public void setGerPessoacaracteristicaCollection(Set<PessoaCaracteristica> gerPessoacaracteristicaCollection) {
		this.gerPessoacaracteristicaCollection = gerPessoacaracteristicaCollection;
	}

}
