package com.gilbertoca.gfi.model.ger;

import java.io.Serializable;
import java.util.Set;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="ger_tpsanguineo")
public class TpSanguineo implements Serializable {
	@Id
	private short cdtpsanguineo;

	private String dctpsanguineo;

	@OneToMany(mappedBy="cdtpsanguineo")
	private Set<PessoaCaracteristica> gerPessoacaracteristicaCollection;

	private static final long serialVersionUID = 1L;

	public TpSanguineo() {
		super();
	}

	public short getCdtpsanguineo() {
		return this.cdtpsanguineo;
	}

	public void setCdtpsanguineo(short cdtpsanguineo) {
		this.cdtpsanguineo = cdtpsanguineo;
	}

	public String getDctpsanguineo() {
		return this.dctpsanguineo;
	}

	public void setDctpsanguineo(String dctpsanguineo) {
		this.dctpsanguineo = dctpsanguineo;
	}

	public Set<PessoaCaracteristica> getGerPessoacaracteristicaCollection() {
		return this.gerPessoacaracteristicaCollection;
	}

	public void setGerPessoacaracteristicaCollection(Set<PessoaCaracteristica> gerPessoacaracteristicaCollection) {
		this.gerPessoacaracteristicaCollection = gerPessoacaracteristicaCollection;
	}

}
