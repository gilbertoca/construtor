package com.gilbertoca.gfi.model.ger;

import java.io.Serializable;
import java.sql.Date;
import java.util.Set;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="ger_pessoa")
public class Pessoa implements Serializable {
	@Id
	private int cdpessoa;

	private String rgnumero;

	@Column(name="log_nome")
	private String logNome;

	private String cnlv;

	private String cep;

	private String cnuf;

	private String fotopath;

	private short fldependente;

	private String cpf;

	private String nomemae;

	private String cnfls;

	private String cncidade;

	private Date rgemissao;

	private String cnsubdistrito;

	@Column(name="log_complemento")
	private String logComplemento;

	private String nomepai;

	private Date dtfalecimento;

	@Column(name="ufe_sg")
	private String ufeSg;

	@Column(name="loc_nu_sequencial")
	private int locNuSequencial;

	private Date dtnascimento;

	@Column(name="bai_nome")
	private String baiNome;

	private short flservidorpublico;

	private String tipologradouro;

	private String esferaservidorpublico;

	private String rgorgaoexp;

	private String cnnumero;

	private String apelido;

	private String sexo;

	private String nome;

	@OneToMany(mappedBy="cdpessoa")
	private Set<PessoaCaracteristica> gerPessoacaracteristicaCollection;

	@OneToMany(mappedBy="cdpessoa")
	private Set<Email> gerEmailCollection;

	@OneToMany(mappedBy="cdpessoa")
	private Set<PessoaDependencia> gerPessoadependenciaCollection;

	@OneToMany(mappedBy="cdpessoa")
	private Set<PessoaDocumento> gerPessoadocumentoCollection;

	@OneToMany(mappedBy="cdpessoa")
	private Set<Telefone> gerTelefoneCollection;

	private static final long serialVersionUID = 1L;

	public Pessoa() {
		super();
	}

	public int getCdpessoa() {
		return this.cdpessoa;
	}

	public void setCdpessoa(int cdpessoa) {
		this.cdpessoa = cdpessoa;
	}

	public String getRgnumero() {
		return this.rgnumero;
	}

	public void setRgnumero(String rgnumero) {
		this.rgnumero = rgnumero;
	}

	public String getLogNome() {
		return this.logNome;
	}

	public void setLogNome(String logNome) {
		this.logNome = logNome;
	}

	public String getCnlv() {
		return this.cnlv;
	}

	public void setCnlv(String cnlv) {
		this.cnlv = cnlv;
	}

	public String getCep() {
		return this.cep;
	}

	public void setCep(String cep) {
		this.cep = cep;
	}

	public String getCnuf() {
		return this.cnuf;
	}

	public void setCnuf(String cnuf) {
		this.cnuf = cnuf;
	}

	public String getFotopath() {
		return this.fotopath;
	}

	public void setFotopath(String fotopath) {
		this.fotopath = fotopath;
	}

	public short getFldependente() {
		return this.fldependente;
	}

	public void setFldependente(short fldependente) {
		this.fldependente = fldependente;
	}

	public String getCpf() {
		return this.cpf;
	}

	public void setCpf(String cpf) {
		this.cpf = cpf;
	}

	public String getNomemae() {
		return this.nomemae;
	}

	public void setNomemae(String nomemae) {
		this.nomemae = nomemae;
	}

	public String getCnfls() {
		return this.cnfls;
	}

	public void setCnfls(String cnfls) {
		this.cnfls = cnfls;
	}

	public String getCncidade() {
		return this.cncidade;
	}

	public void setCncidade(String cncidade) {
		this.cncidade = cncidade;
	}

	public Date getRgemissao() {
		return this.rgemissao;
	}

	public void setRgemissao(Date rgemissao) {
		this.rgemissao = rgemissao;
	}

	public String getCnsubdistrito() {
		return this.cnsubdistrito;
	}

	public void setCnsubdistrito(String cnsubdistrito) {
		this.cnsubdistrito = cnsubdistrito;
	}

	public String getLogComplemento() {
		return this.logComplemento;
	}

	public void setLogComplemento(String logComplemento) {
		this.logComplemento = logComplemento;
	}

	public String getNomepai() {
		return this.nomepai;
	}

	public void setNomepai(String nomepai) {
		this.nomepai = nomepai;
	}

	public Date getDtfalecimento() {
		return this.dtfalecimento;
	}

	public void setDtfalecimento(Date dtfalecimento) {
		this.dtfalecimento = dtfalecimento;
	}

	public String getUfeSg() {
		return this.ufeSg;
	}

	public void setUfeSg(String ufeSg) {
		this.ufeSg = ufeSg;
	}

	public int getLocNuSequencial() {
		return this.locNuSequencial;
	}

	public void setLocNuSequencial(int locNuSequencial) {
		this.locNuSequencial = locNuSequencial;
	}

	public Date getDtnascimento() {
		return this.dtnascimento;
	}

	public void setDtnascimento(Date dtnascimento) {
		this.dtnascimento = dtnascimento;
	}

	public String getBaiNome() {
		return this.baiNome;
	}

	public void setBaiNome(String baiNome) {
		this.baiNome = baiNome;
	}

	public short getFlservidorpublico() {
		return this.flservidorpublico;
	}

	public void setFlservidorpublico(short flservidorpublico) {
		this.flservidorpublico = flservidorpublico;
	}

	public String getTipologradouro() {
		return this.tipologradouro;
	}

	public void setTipologradouro(String tipologradouro) {
		this.tipologradouro = tipologradouro;
	}

	public String getEsferaservidorpublico() {
		return this.esferaservidorpublico;
	}

	public void setEsferaservidorpublico(String esferaservidorpublico) {
		this.esferaservidorpublico = esferaservidorpublico;
	}

	public String getRgorgaoexp() {
		return this.rgorgaoexp;
	}

	public void setRgorgaoexp(String rgorgaoexp) {
		this.rgorgaoexp = rgorgaoexp;
	}

	public String getCnnumero() {
		return this.cnnumero;
	}

	public void setCnnumero(String cnnumero) {
		this.cnnumero = cnnumero;
	}

	public String getApelido() {
		return this.apelido;
	}

	public void setApelido(String apelido) {
		this.apelido = apelido;
	}

	public String getSexo() {
		return this.sexo;
	}

	public void setSexo(String sexo) {
		this.sexo = sexo;
	}

	public String getNome() {
		return this.nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public Set<PessoaCaracteristica> getGerPessoacaracteristicaCollection() {
		return this.gerPessoacaracteristicaCollection;
	}

	public void setGerPessoacaracteristicaCollection(Set<PessoaCaracteristica> gerPessoacaracteristicaCollection) {
		this.gerPessoacaracteristicaCollection = gerPessoacaracteristicaCollection;
	}

	public Set<Email> getGerEmailCollection() {
		return this.gerEmailCollection;
	}

	public void setGerEmailCollection(Set<Email> gerEmailCollection) {
		this.gerEmailCollection = gerEmailCollection;
	}

	public Set<PessoaDependencia> getGerPessoadependenciaCollection() {
		return this.gerPessoadependenciaCollection;
	}

	public void setGerPessoadependenciaCollection(Set<PessoaDependencia> gerPessoadependenciaCollection) {
		this.gerPessoadependenciaCollection = gerPessoadependenciaCollection;
	}

	public Set<PessoaDocumento> getGerPessoadocumentoCollection() {
		return this.gerPessoadocumentoCollection;
	}

	public void setGerPessoadocumentoCollection(Set<PessoaDocumento> gerPessoadocumentoCollection) {
		this.gerPessoadocumentoCollection = gerPessoadocumentoCollection;
	}

	public Set<Telefone> getGerTelefoneCollection() {
		return this.gerTelefoneCollection;
	}

	public void setGerTelefoneCollection(Set<Telefone> gerTelefoneCollection) {
		this.gerTelefoneCollection = gerTelefoneCollection;
	}

}
