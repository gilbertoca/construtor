package com.gilbertoca.gfi.model.ger;

import java.io.Serializable;
import javax.persistence.Embeddable;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="ger_telefone")
public class Telefone implements Serializable {
	@EmbeddedId
	private Telefone.PK pk;

	private String tptelefone;

	@ManyToOne
	@JoinColumn(name="cdpessoa")
	private Pessoa cdpessoa;

	private static final long serialVersionUID = 1L;

	public Telefone() {
		super();
	}

	public Telefone.PK getPk() {
		return this.pk;
	}

	public void setPk(Telefone.PK pk) {
		this.pk = pk;
	}

	public String getTptelefone() {
		return this.tptelefone;
	}

	public void setTptelefone(String tptelefone) {
		this.tptelefone = tptelefone;
	}

	public Pessoa getCdpessoa() {
		return this.cdpessoa;
	}

	public void setCdpessoa(Pessoa cdpessoa) {
		this.cdpessoa = cdpessoa;
	}


	@Embeddable
	public static class PK implements Serializable {
		private String telefone;
		private int cdpessoa2;
		private static final long serialVersionUID = 1L;

		public PK() {
			super();
		}

		public String getTelefone() {
			return this.telefone;
		}

		public void setTelefone(String telefone) {
			this.telefone = telefone;
		}

		public int getCdpessoa2() {
			return this.cdpessoa2;
		}

		public void setCdpessoa2(int cdpessoa2) {
			this.cdpessoa2 = cdpessoa2;
		}

		@Override
		public boolean equals(Object o) {
			if (o == this) {
				return true;
			}
			if ( ! (o instanceof PK)) {
				return false;
			}
			PK other = (PK) o;
			return this.telefone.equals(other.telefone)
				&& (this.cdpessoa2 == other.cdpessoa2);
		}

		@Override
		public int hashCode() {
			return this.telefone.hashCode()
				^ this.cdpessoa2;
		}

	}

}
